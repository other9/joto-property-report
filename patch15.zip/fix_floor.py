"""Fix floor parsing in scraper.py to handle basement floors (地下)"""
import re

filepath = "src/scraper.py"
with open(filepath, "r") as f:
    content = f.read()

# Old: single-line floor regex that ignores 地下
old = '''fm=re.search(r"(\\d+)階[／/](\\d+)階建",text);floor=f"{fm.group(1)}階／{fm.group(2)}階建" if fm else None'''

# New: multi-line with 地下/B prefix support
new = '''# 階数パース（地下対応）
    bfm=re.search(r"地下(\\d+)階[／/](\\d+)階建",text)
    nfm=re.search(r"(?<!地下)(\\d+)階[／/](\\d+)階建",text)
    if bfm:
        floor=f"B{bfm.group(1)}階／{bfm.group(2)}階建"
    elif nfm:
        floor=f"{nfm.group(1)}階／{nfm.group(2)}階建"
    else:
        floor=None'''

if old in content:
    content = content.replace(old, new)
    with open(filepath, "w") as f:
        f.write(content)
    print("✅ Floor parsing fixed (地下 support added)")
else:
    print("⚠ Exact match not found, trying alternate pattern...")
    # Try a more flexible match
    pattern = r'fm=re\.search\(r"\(\\d\+\)階.*?floor=.*?None'
    if re.search(pattern, content):
        content = re.sub(
            r'fm=re\.search\(r"\(\\d\+\)階\[／/\]\(\\d\+\)階建",text\);floor=f"\{fm\.group\(1\)\}階／\{fm\.group\(2\)\}階建" if fm else None',
            new,
            content
        )
        with open(filepath, "w") as f:
            f.write(content)
        print("✅ Floor parsing fixed (alternate match)")
    else:
        print("❌ Could not find floor regex to patch. Manual edit needed.")
        print("   Replace the line containing '階[／/]' regex with:")
        print(new)
