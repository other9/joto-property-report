このパッチの適用方法
===================

Codespace のターミナルで以下を実行:

  cd /workspaces/joto-property-report
  unzip -o ~/patch.zip
  git add -A
  git commit -m "fix: dedup properties + fix condo merge + model name"
  git push origin main

修正内容:
- src/config.py  : モデル名を claude-sonnet-4-6 に統一
- src/scraper.py  : 価格+面積+築年月による物件実体の重複排除を追加
- src/analyzer.py : Claude応答のJSON抽出を強化、分析結果のURL重複排除、元データマージ修正
