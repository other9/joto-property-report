# 城東エリア不動産投資レポート 自動生成

GitHub Actions + Claude API で毎日AM9:00(JST)に城東7区の不動産データを自動収集・分析し、GitHub Pagesにレポートを公開するシステム。

## 対象

| カテゴリ | 対象エリア | 予算 |
|---------|-----------|------|
| 売り店舗・事務所 | 台東区・墨田区・江東区・荒川区・足立区・葛飾区・江戸川区 | 5,000万円以下 |
| 区分マンション | 同上 | 5,000万円以下 |
| 戸建て | 同上 | 5,000万円以下 |

**投資条件**: 自己資金2,000万円以下 + 融資3,000万円以下

## 分析内容

- **物件スコアリング**: 立地30点/利回り20点/テナント需要20点/将来性15点/資金効率15点
- **想定テナント属性**: エリア特性に基づく具体的なテナント候補
- **想定賃料**: 周辺賃料相場データに基づく推定
- **賃料参考物件**: SUUMO等の近隣賃貸データとの比較
- **融資適格度**: A(銀行融資確実)/B(ノンバンク可)/C(現金推奨)
- **差分検出**: 前日からの新着・成約・価格変更を自動検出

## セットアップ手順

### 1. リポジトリ作成

```bash
gh repo create joto-property-report --private
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/joto-property-report.git
git push -u origin main
```

### 2. GitHub Secrets の設定（必須）

リポジトリの **Settings → Secrets and variables → Actions** で以下を設定:

| Secret名 | 値 | 説明 |
|----------|---|------|
| `ANTHROPIC_API_KEY` | `sk-ant-...` | Claude APIキー（[console.anthropic.com](https://console.anthropic.com) で取得） |

### 3. GitHub Pages の有効化

1. **Settings → Pages**
2. **Source** を `Deploy from a branch` に設定
3. **Branch** を `gh-pages` / `/ (root)` に設定
4. Save

### 4. Actions の有効化

1. **Actions** タブを開く
2. 「I understand my workflows, go ahead and enable them」をクリック

### 5. 手動テスト実行

1. **Actions** → **城東エリア不動産レポート自動生成**
2. **Run workflow** → **Run workflow** ボタンをクリック
3. 約5〜10分でレポートが生成される
4. `https://<YOUR_USERNAME>.github.io/joto-property-report/` でレポートを確認

## 設定カスタマイズ

### 実行スケジュール変更

`.github/workflows/daily_report.yml` の cron 式を変更:

```yaml
schedule:
  - cron: '0 0 * * *'    # 毎日AM9:00 JST
  - cron: '0 0 * * 1'    # 毎週月曜AM9:00 JST
  - cron: '0 0 1 * *'    # 毎月1日AM9:00 JST
```

### 対象エリア変更

`src/config.py` の `JOTO_WARDS` を編集:

```python
JOTO_WARDS = {
    "shinjuku-ku": "新宿区",  # 追加例
    ...
}
```

### 予算変更

`src/config.py` の `BUDGET` を編集:

```python
BUDGET = {
    "self_fund_max": 30_000_000,  # 自己資金3,000万に変更
    "loan_max":      50_000_000,  # 融資5,000万に変更
    "total_max":     80_000_000,
}
```

### Slack通知を有効化

1. Slack Incoming Webhook URL を取得
2. GitHub Secrets に `SLACK_WEBHOOK_URL` を追加
3. `.github/workflows/daily_report.yml` の通知セクションをアンコメント

## ファイル構成

```
joto-property-report/
├── .github/workflows/
│   └── daily_report.yml     # GitHub Actions ワークフロー
├── src/
│   ├── config.py            # 設定（エリア・予算・パラメータ）
│   ├── scraper.py           # スクレイピング（健美家・goo不動産・SUUMO）
│   ├── analyzer.py          # Claude API 分析
│   └── report_generator.py  # HTML レポート生成
├── templates/
│   └── report.html          # Jinja2 HTMLテンプレート
├── data/                    # (自動生成) スクレイピング・分析データ
├── output/                  # (自動生成) HTMLレポート出力
├── requirements.txt
├── .gitignore
└── README.md
```

## API利用料の目安

- Claude API (claude-sonnet-4): 1回の分析で約$0.05〜0.15
- 毎日実行で月額約$2〜5程度
- 週1回実行なら月額$0.5〜1程度

## 注意事項

- 不動産サイトのスクレイピングは各サイトの利用規約に従ってください
- リクエスト間隔（`DELAY`）を適切に設定し、サーバーに負荷をかけないようにしてください
- 本レポートはAI分析に基づく参考情報であり、投資判断は自己責任で行ってください
- 融資適格度はAI推定であり、実際の融資可否は金融機関の審査によります
