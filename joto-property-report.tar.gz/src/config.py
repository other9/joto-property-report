"""城東エリア不動産レポート - 設定"""

import os
from dataclasses import dataclass, field

# ───────────────────────────────────────
# 対象エリア（城東7区）
# ───────────────────────────────────────
JOTO_WARDS = {
    "taito-ku":     "台東区",
    "sumida-ku":    "墨田区",
    "koto-ku":      "江東区",
    "arakawa-ku":   "荒川区",
    "adachi-ku":    "足立区",
    "katsushika-ku":"葛飾区",
    "edogawa-ku":   "江戸川区",
}

# ───────────────────────────────────────
# 物件カテゴリ
# ───────────────────────────────────────
PROPERTY_CATEGORIES = {
    "store":  {"label": "売り店舗・事務所", "kenbiya_path": "pp6", "budget_max": 50_000_000},
    "condo":  {"label": "区分マンション",   "kenbiya_path": "pp0", "budget_max": 50_000_000},
    "house":  {"label": "戸建て",          "kenbiya_path": "pp3", "budget_max": 50_000_000},
}

# ───────────────────────────────────────
# スクレイピング対象URL
# ───────────────────────────────────────
def kenbiya_urls():
    """健美家のスクレイピング対象URLを生成"""
    urls = []
    for ward_key, ward_name in JOTO_WARDS.items():
        for cat_key, cat in PROPERTY_CATEGORIES.items():
            urls.append({
                "source":   "kenbiya",
                "category": cat_key,
                "ward_key": ward_key,
                "ward":     ward_name,
                "url":      f"https://www.kenbiya.com/{cat['kenbiya_path']}/s/tokyo/{ward_key}/",
                "label":    f"{ward_name} {cat['label']}",
            })
    return urls

def suumo_rent_urls():
    """SUUMO賃料相場ページURL（参考賃料用）"""
    # 城東エリアの賃料相場データ
    return [
        {"ward": "台東区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_taito/"},
        {"ward": "墨田区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_sumida/"},
        {"ward": "江東区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_koto/"},
        {"ward": "荒川区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_arakawa/"},
        {"ward": "足立区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_adachi/"},
        {"ward": "葛飾区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_katsushika/"},
        {"ward": "江戸川区", "url": "https://suumo.jp/chintai/soba/tokyo/sc_edogawa/"},
    ]

# ───────────────────────────────────────
# 投資判断パラメータ
# ───────────────────────────────────────
BUDGET = {
    "self_fund_max":  20_000_000,   # 自己資金上限
    "loan_max":       30_000_000,   # 融資上限
    "total_max":      50_000_000,   # 総予算上限
}

# 融資分析パラメータ
LOAN_PARAMS = {
    "interest_rate":  0.025,        # 想定金利 2.5%
    "term_years":     25,           # 融資期間 25年
    "ltv_max":        0.80,         # LTV上限 80%
    "dscr_min":       1.20,         # DSCR下限 1.2倍
}

# スコアリング配点（100点満点）
SCORING_WEIGHTS = {
    "location":       30,   # 立地（駅距離・視認性）
    "yield_return":   20,   # 利回り
    "tenant_demand":  20,   # テナント需要
    "future_value":   15,   # 将来性（地価上昇率等）
    "capital_eff":    15,   # 資金効率
}

# ───────────────────────────────────────
# Claude API設定
# ───────────────────────────────────────
CLAUDE_MODEL = "claude-sonnet-4-20250514"
CLAUDE_MAX_TOKENS = 8000

# ───────────────────────────────────────
# 出力設定
# ───────────────────────────────────────
OUTPUT_DIR = "output"
DATA_DIR = "data"
