"""城東エリア不動産レポート HTML生成

analysis.json からHTMLレポートを生成し、GitHub Pagesにデプロイ可能な形で出力する。
過去レポートとの差分（新着・成約・価格変更）も検出する。
"""

import json
import os
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

from jinja2 import Environment, FileSystemLoader

from config import DATA_DIR, OUTPUT_DIR, PROPERTY_CATEGORIES, JOTO_WARDS, BUDGET

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

JST = timezone(timedelta(hours=9))


def detect_changes(current: dict, previous_path: str) -> dict:
    """前回レポートとの差分を検出"""
    changes = {"new": [], "removed": [], "price_changed": []}

    if not os.path.exists(previous_path):
        return changes

    try:
        with open(previous_path, "r", encoding="utf-8") as f:
            previous = json.load(f)
    except Exception:
        return changes

    prev_urls = {}
    for cat_results in previous.get("results", {}).values():
        for p in cat_results:
            prev_urls[p["url"]] = p

    curr_urls = {}
    for cat_results in current.get("results", {}).values():
        for p in cat_results:
            curr_urls[p["url"]] = p

    # 新着物件
    for url, prop in curr_urls.items():
        if url not in prev_urls:
            changes["new"].append(prop)

    # 成約（消滅）物件
    for url, prop in prev_urls.items():
        if url not in curr_urls:
            changes["removed"].append(prop)

    # 価格変更
    for url in set(curr_urls) & set(prev_urls):
        curr_price = curr_urls[url].get("price", 0)
        prev_price = prev_urls[url].get("price", 0)
        if curr_price != prev_price and prev_price > 0:
            changes["price_changed"].append({
                **curr_urls[url],
                "prev_price": prev_price,
                "price_diff": curr_price - prev_price,
            })

    return changes


def main():
    Path(OUTPUT_DIR).mkdir(exist_ok=True)

    # 分析データ読み込み
    analysis_path = os.path.join(DATA_DIR, "analysis.json")
    if not os.path.exists(analysis_path):
        log.error(f"{analysis_path} が見つかりません")
        return

    with open(analysis_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 差分検出
    prev_path = os.path.join(OUTPUT_DIR, "latest_analysis.json")
    changes = detect_changes(data, prev_path)
    log.info(f"差分: 新着{len(changes['new'])}件 / 成約{len(changes['removed'])}件 / 価格変更{len(changes['price_changed'])}件")

    # テンプレートからHTML生成
    env = Environment(
        loader=FileSystemLoader("templates"),
        autoescape=True,
    )
    template = env.get_template("report.html")

    report_date = data.get("analyzed_at", datetime.now(JST).strftime("%Y-%m-%d"))

    html = template.render(
        report_date=report_date,
        categories=PROPERTY_CATEGORIES,
        wards=JOTO_WARDS,
        results=data["results"],
        rent_data=data.get("rent_data", {}),
        ward_counts=data.get("ward_counts", {}),
        budget=BUDGET,
        changes=changes,
        total_props=sum(len(v) for v in data["results"].values()),
    )

    # HTML出力
    html_path = os.path.join(OUTPUT_DIR, "index.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    log.info(f"HTML出力: {html_path}")

    # 最新分析データを保存（次回差分用）
    with open(prev_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    # 日付別アーカイブ
    archive_path = os.path.join(OUTPUT_DIR, f"report_{report_date}.html")
    with open(archive_path, "w", encoding="utf-8") as f:
        f.write(html)

    log.info(f"=== レポート生成完了 ===")


if __name__ == "__main__":
    main()
