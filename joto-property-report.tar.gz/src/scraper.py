"""城東エリア不動産データ スクレイパー

健美家/HOMES、goo不動産から物件データを収集し、
SUUMO等から賃料相場データを取得する。
"""

import json
import os
import re
import time
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
from bs4 import BeautifulSoup

from config import (
    JOTO_WARDS, PROPERTY_CATEGORIES, BUDGET,
    kenbiya_urls, suumo_rent_urls,
    DATA_DIR,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)

JST = timezone(timedelta(hours=9))
TODAY = datetime.now(JST).strftime("%Y-%m-%d")

HEADERS = {
    "User-Agent": os.getenv("USER_AGENT", "JotoPropertyReport/1.0"),
    "Accept-Language": "ja,en;q=0.9",
}
DELAY = 2  # リクエスト間隔（秒）


# ═══════════════════════════════════════════
# 健美家スクレイパー
# ═══════════════════════════════════════════
def scrape_kenbiya_page(url: str, category: str, ward: str) -> list[dict]:
    """健美家の1ページから物件リストを抽出"""
    props = []
    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")
    except Exception as e:
        log.warning(f"Failed to fetch {url}: {e}")
        return props

    # 物件行を抽出（テーブル構造）
    rows = soup.select("table.search-result-table tbody tr, div.property-list-item, li[class*='property']")

    # 健美家のリスト構造はリンク群から抽出
    links = soup.select("a[href*='/re_']")
    seen_urls = set()

    for link in links:
        href = link.get("href", "")
        if "/re_" not in href or href in seen_urls:
            continue
        seen_urls.add(href)

        full_url = f"https://www.kenbiya.com{href}" if href.startswith("/") else href

        # 親要素からテキスト情報を抽出
        parent = link
        for _ in range(5):
            parent = parent.parent
            if parent is None:
                break
        if parent is None:
            continue

        text = parent.get_text(separator="|", strip=True)

        prop = parse_kenbiya_text(text, full_url, category, ward)
        if prop:
            props.append(prop)

    log.info(f"  {ward} {category}: {len(props)} properties found")
    return props


def parse_kenbiya_text(text: str, url: str, category: str, ward: str) -> dict | None:
    """健美家のテキストブロックから物件情報をパース"""

    # 価格抽出
    price_match = re.search(r"([\d,]+)万円", text)
    if not price_match:
        return None
    price = int(price_match.group(1).replace(",", ""))

    # 利回り抽出
    yield_match = re.search(r"([\d.]+)[％%]", text)
    yield_pct = float(yield_match.group(1)) if yield_match else None

    # 面積抽出
    area_match = re.search(r"専?[：:]?([\d.]+)\s*m[²㎡]", text)
    if not area_match:
        area_match = re.search(r"([\d.]+)\s*m[²㎡]", text)
    size = float(area_match.group(1)) if area_match else None

    # 築年月抽出
    built_match = re.search(r"(\d{4})年(\d{1,2})月", text)
    built = f"{built_match.group(1)}年{built_match.group(2)}月" if built_match else None

    # 駅情報抽出
    station_match = re.search(r"([\w・]+(?:線|ライン))\s*([\w]+駅)\s*歩?(\d+)分", text)
    station = None
    walk_min = None
    if station_match:
        station = f"{station_match.group(2)} 徒歩{station_match.group(3)}分"
        walk_min = int(station_match.group(3))

    # 階数抽出
    floor_match = re.search(r"(\d+)階[／/](\d+)階建", text)
    floor_info = f"{floor_match.group(1)}階／{floor_match.group(2)}階建" if floor_match else None

    # 住所抽出
    addr_match = re.search(r"東京都([\w区市]+[\w\d丁目\-]+)", text)
    address = addr_match.group(0) if addr_match else f"東京都{ward}"

    # タイトル抽出（最初の見出し的テキスト）
    title_parts = text.split("|")
    title = ""
    for part in title_parts:
        part = part.strip()
        if len(part) > 5 and ("区" in part or "万円" not in part[:10]):
            title = part[:60]
            break

    return {
        "url":       url,
        "source":    "健美家／HOMES",
        "category":  category,
        "ward":      ward,
        "title":     title,
        "price":     price,            # 万円
        "yield_pct": yield_pct,        # %
        "size":      size,             # ㎡
        "built":     built,
        "station":   station,
        "walk_min":  walk_min,
        "floor":     floor_info,
        "address":   address,
        "scraped_at": TODAY,
    }


# ═══════════════════════════════════════════
# goo不動産スクレイパー
# ═══════════════════════════════════════════
def scrape_goo_realestate() -> list[dict]:
    """goo不動産（投資物件）から城東エリアの物件を取得"""
    props = []
    url = "https://house.goo.ne.jp/toushi/office/area_tokyo.html"

    try:
        resp = requests.get(url, headers=HEADERS, timeout=30)
        resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")
    except Exception as e:
        log.warning(f"Failed to fetch goo: {e}")
        return props

    rows = soup.select("div.property-item, tr.property-row, div.bukken, li.result-item")
    links = soup.select("a[href*='/toushi/detail/']")
    seen = set()

    for link in links:
        href = link.get("href", "")
        if href in seen:
            continue
        seen.add(href)

        full_url = f"https://house.goo.ne.jp{href}" if href.startswith("/") else href

        parent = link
        for _ in range(6):
            if parent.parent:
                parent = parent.parent

        text = parent.get_text(separator="|", strip=True)

        # 城東エリアの物件のみ抽出
        is_joto = any(w in text for w in JOTO_WARDS.values())
        if not is_joto:
            continue

        # 所属区を特定
        ward = "不明"
        for w_name in JOTO_WARDS.values():
            if w_name in text:
                ward = w_name
                break

        prop = parse_kenbiya_text(text, full_url, "store", ward)
        if prop:
            prop["source"] = "goo不動産"
            props.append(prop)

    log.info(f"  goo不動産: {len(props)} joto properties found")
    return props


# ═══════════════════════════════════════════
# 賃料相場データ取得
# ═══════════════════════════════════════════
def scrape_rent_data() -> dict:
    """各区の賃料相場データを取得（SUUMO等）"""
    rent_data = {}

    for item in suumo_rent_urls():
        ward = item["ward"]
        url = item["url"]
        try:
            resp = requests.get(url, headers=HEADERS, timeout=30)
            if resp.status_code == 200:
                soup = BeautifulSoup(resp.text, "lxml")
                text = soup.get_text()
                # 賃料データの抽出（テーブルから）
                rent_data[ward] = extract_rent_from_page(soup, ward)
            else:
                log.warning(f"  Rent data {ward}: HTTP {resp.status_code}")
                rent_data[ward] = get_fallback_rent(ward)
        except Exception as e:
            log.warning(f"  Rent data {ward} failed: {e}")
            rent_data[ward] = get_fallback_rent(ward)

        time.sleep(DELAY)

    return rent_data


def extract_rent_from_page(soup: BeautifulSoup, ward: str) -> dict:
    """SUUMOのページから賃料相場を抽出"""
    data = get_fallback_rent(ward)  # デフォルト値

    text = soup.get_text()

    # 間取り別賃料のパターンマッチ
    patterns = {
        "1R":    r"1R[^0-9]*([\d.]+)万円",
        "1K":    r"1K[^0-9]*([\d.]+)万円",
        "1LDK":  r"1LDK[^0-9]*([\d.]+)万円",
        "2LDK":  r"2LDK[^0-9]*([\d.]+)万円",
        "3LDK":  r"3LDK[^0-9]*([\d.]+)万円",
    }
    for layout, pat in patterns.items():
        m = re.search(pat, text)
        if m:
            data[layout] = float(m.group(1))

    return data


def get_fallback_rent(ward: str) -> dict:
    """フォールバック用の賃料相場データ（2025年時点の概算）"""
    # 各区の概算値（万円/月）
    defaults = {
        "台東区":  {"1R": 9.5, "1K": 10.2, "1LDK": 14.8, "2LDK": 19.5, "3LDK": 24.0, "store_tsubo": 2.2},
        "墨田区":  {"1R": 8.8, "1K": 9.5,  "1LDK": 13.5, "2LDK": 17.0, "3LDK": 21.0, "store_tsubo": 1.8},
        "江東区":  {"1R": 9.2, "1K": 10.0, "1LDK": 14.0, "2LDK": 18.5, "3LDK": 23.0, "store_tsubo": 2.0},
        "荒川区":  {"1R": 7.8, "1K": 8.5,  "1LDK": 12.0, "2LDK": 15.0, "3LDK": 19.0, "store_tsubo": 1.5},
        "足立区":  {"1R": 6.5, "1K": 7.2,  "1LDK": 10.0, "2LDK": 12.5, "3LDK": 15.0, "store_tsubo": 1.2},
        "葛飾区":  {"1R": 6.3, "1K": 7.0,  "1LDK": 9.8,  "2LDK": 12.0, "3LDK": 14.5, "store_tsubo": 1.1},
        "江戸川区": {"1R": 6.5, "1K": 7.0,  "1LDK": 10.0, "2LDK": 12.0, "3LDK": 14.5, "store_tsubo": 1.1},
    }
    return defaults.get(ward, {"1R": 7.0, "1K": 8.0, "1LDK": 11.0, "2LDK": 14.0, "3LDK": 17.0, "store_tsubo": 1.5})


# ═══════════════════════════════════════════
# メイン処理
# ═══════════════════════════════════════════
def main():
    Path(DATA_DIR).mkdir(exist_ok=True)
    all_props = []

    # 1. 健美家スクレイピング
    log.info("=== 健美家 スクレイピング開始 ===")
    for target in kenbiya_urls():
        props = scrape_kenbiya_page(
            url=target["url"],
            category=target["category"],
            ward=target["ward"],
        )
        all_props.extend(props)
        time.sleep(DELAY)

    # 2. goo不動産スクレイピング
    log.info("=== goo不動産 スクレイピング開始 ===")
    goo_props = scrape_goo_realestate()
    all_props.extend(goo_props)

    # 3. 重複排除（URLベース）
    seen_urls = set()
    unique_props = []
    for p in all_props:
        if p["url"] not in seen_urls:
            seen_urls.add(p["url"])
            unique_props.append(p)

    # 4. 賃料相場データ取得
    log.info("=== 賃料相場データ取得 ===")
    rent_data = scrape_rent_data()

    # 5. JSON保存
    output = {
        "scraped_at": TODAY,
        "total_properties": len(unique_props),
        "properties": unique_props,
        "rent_data": rent_data,
        "ward_counts": {},
    }

    # 区×カテゴリ別の件数集計
    for ward in JOTO_WARDS.values():
        output["ward_counts"][ward] = {}
        for cat in PROPERTY_CATEGORIES:
            count = sum(1 for p in unique_props if p["ward"] == ward and p["category"] == cat)
            output["ward_counts"][ward][cat] = count

    outpath = os.path.join(DATA_DIR, "properties.json")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    log.info(f"=== 完了: {len(unique_props)}件を {outpath} に保存 ===")

    # サマリー表示
    for cat_key, cat in PROPERTY_CATEGORIES.items():
        count = sum(1 for p in unique_props if p["category"] == cat_key)
        budget_count = sum(1 for p in unique_props
                          if p["category"] == cat_key and p["price"] <= BUDGET["total_max"] / 10000)
        log.info(f"  {cat['label']}: {count}件（うち予算内: {budget_count}件）")


if __name__ == "__main__":
    main()
