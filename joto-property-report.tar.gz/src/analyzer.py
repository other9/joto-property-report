"""城東エリア不動産分析 - Claude API連携

スクレイピングで収集した物件データをClaude APIに渡し、
想定テナント属性、想定賃料、融資分析、スコアリングを行う。
"""

import json
import os
import logging
from pathlib import Path

import anthropic

from config import (
    BUDGET, LOAN_PARAMS, SCORING_WEIGHTS,
    CLAUDE_MODEL, CLAUDE_MAX_TOKENS,
    DATA_DIR, PROPERTY_CATEGORIES,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger(__name__)


def build_analysis_prompt(properties: list[dict], rent_data: dict, category: str) -> str:
    """Claude APIに送る分析プロンプトを構築"""

    cat_label = PROPERTY_CATEGORIES[category]["label"]

    props_text = json.dumps(properties, ensure_ascii=False, indent=2)
    rent_text = json.dumps(rent_data, ensure_ascii=False, indent=2)

    return f"""あなたは東京の不動産投資アナリストです。以下の城東エリア（台東区・墨田区・江東区・荒川区・足立区・葛飾区・江戸川区）の{cat_label}物件データを分析してください。

## 投資条件
- 自己資金上限: {BUDGET['self_fund_max'] // 10000}万円
- 融資上限: {BUDGET['loan_max'] // 10000}万円（応相談で拡大可）
- 想定金利: {LOAN_PARAMS['interest_rate'] * 100}%
- 融資期間: {LOAN_PARAMS['term_years']}年
- LTV上限: {LOAN_PARAMS['ltv_max'] * 100}%
- DSCR下限: {LOAN_PARAMS['dscr_min']}倍

## 物件データ
{props_text}

## 城東エリア賃料相場データ
{rent_text}

## 分析指示
各物件について以下をJSON配列で出力してください。JSONのみ出力し、Markdown等は不要です。

```json
[
  {{
    "url": "物件URL",
    "rank": 1,
    "score": 92,
    "score_breakdown": {{
      "location": 28,
      "yield_return": 18,
      "tenant_demand": 19,
      "future_value": 14,
      "capital_eff": 13
    }},
    "tenant_type": "想定テナント属性（具体的に3-4業種）",
    "estimated_rent": "想定月額賃料の範囲（例: 18〜22万円/月）",
    "rent_reference": "参考とした近隣賃貸物件や相場データ",
    "analysis": "150字以内の投資分析",
    "loan_analysis": {{
      "feasibility": "A/B/C",
      "reason": "融資の付きやすさの理由（80字以内）",
      "recommended_plan": {{
        "self_fund": 1280,
        "loan": 3000,
        "monthly_repay": 13.5,
        "dscr": 1.35
      }}
    }},
    "pros": ["メリット1", "メリット2", "メリット3"],
    "cons": ["リスク1", "リスク2"],
    "over_budget": false
  }}
]
```

## スコアリング基準
- location（{SCORING_WEIGHTS['location']}点）: 駅距離、路面店か否か、通行量、視認性
- yield_return（{SCORING_WEIGHTS['yield_return']}点）: 表面利回り、実質利回り推定
- tenant_demand（{SCORING_WEIGHTS['tenant_demand']}点）: エリアのテナント需要、業種適合性
- future_value（{SCORING_WEIGHTS['future_value']}点）: 地価上昇率、再開発計画
- capital_eff（{SCORING_WEIGHTS['capital_eff']}点）: 自己資金回収期間、ROE

## 融資分析基準（feasibility）
- A: 新耐震基準、築30年以内、駅徒歩10分以内、利回り5%以上 → 銀行融資ほぼ確実
- B: 旧耐震だが立地良好、利回り高い → ノンバンク含め融資可能
- C: 築古・駅遠・利回り低い → 現金購入推奨

## rent_reference（賃料参考）
必ず以下を含めてください：
- 当該エリアの同規模・同用途の賃貸物件の賃料例
- 上記の賃料相場データとの整合性
- 店舗の場合は坪単価も明記

上位10件をスコア降順で出力してください。予算超過物件は over_budget: true としてください。"""


def analyze_category(client: anthropic.Anthropic, properties: list[dict],
                     rent_data: dict, category: str) -> list[dict]:
    """1カテゴリの物件をClaude APIで分析"""

    if not properties:
        log.info(f"  {category}: 物件なし、スキップ")
        return []

    # 予算内優先で最大30件に絞る（APIトークン節約）
    budget_max = BUDGET["total_max"] // 10000
    in_budget = [p for p in properties if p["price"] <= budget_max]
    over_budget = [p for p in properties if p["price"] > budget_max]
    over_budget.sort(key=lambda x: x.get("yield_pct") or 0, reverse=True)
    selected = in_budget + over_budget[:max(10 - len(in_budget), 5)]
    selected = selected[:30]

    prompt = build_analysis_prompt(selected, rent_data, category)

    log.info(f"  {category}: {len(selected)}件をClaude APIに送信中...")

    try:
        message = client.messages.create(
            model=CLAUDE_MODEL,
            max_tokens=CLAUDE_MAX_TOKENS,
            messages=[{"role": "user", "content": prompt}],
        )
        response_text = message.content[0].text

        # JSON部分を抽出
        response_text = response_text.strip()
        if response_text.startswith("```"):
            response_text = response_text.split("\n", 1)[1]
            response_text = response_text.rsplit("```", 1)[0]

        results = json.loads(response_text)
        log.info(f"  {category}: {len(results)}件の分析結果を取得")

        # 元データとマージ
        url_map = {p["url"]: p for p in selected}
        for r in results:
            if r["url"] in url_map:
                r.update({
                    k: v for k, v in url_map[r["url"]].items()
                    if k not in r
                })

        return results

    except json.JSONDecodeError as e:
        log.error(f"  {category}: JSON解析エラー: {e}")
        log.error(f"  Response: {response_text[:500]}")
        return []
    except Exception as e:
        log.error(f"  {category}: API呼び出しエラー: {e}")
        return []


def main():
    # データ読み込み
    data_path = os.path.join(DATA_DIR, "properties.json")
    if not os.path.exists(data_path):
        log.error(f"{data_path} が見つかりません。先に scraper.py を実行してください。")
        return

    with open(data_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    properties = data["properties"]
    rent_data = data["rent_data"]
    log.info(f"=== 分析開始: {len(properties)}件 ===")

    # Claude APIクライアント初期化
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        log.error("ANTHROPIC_API_KEY が設定されていません")
        return

    client = anthropic.Anthropic(api_key=api_key)

    # カテゴリ別に分析
    all_results = {}
    for cat_key in PROPERTY_CATEGORIES:
        cat_props = [p for p in properties if p["category"] == cat_key]
        log.info(f"--- {PROPERTY_CATEGORIES[cat_key]['label']}: {len(cat_props)}件 ---")
        results = analyze_category(client, cat_props, rent_data, cat_key)
        all_results[cat_key] = results

    # 分析結果を保存
    output = {
        "analyzed_at": data["scraped_at"],
        "results": all_results,
        "rent_data": rent_data,
        "ward_counts": data["ward_counts"],
        "budget": BUDGET,
        "loan_params": LOAN_PARAMS,
    }

    outpath = os.path.join(DATA_DIR, "analysis.json")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # サマリー
    for cat_key, results in all_results.items():
        label = PROPERTY_CATEGORIES[cat_key]["label"]
        in_budget = sum(1 for r in results if not r.get("over_budget"))
        log.info(f"  {label}: 分析{len(results)}件（予算内{in_budget}件）")

    log.info(f"=== 分析完了: {outpath} に保存 ===")


if __name__ == "__main__":
    main()
